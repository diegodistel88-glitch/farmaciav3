# Grandes hospitales: cómo gestionan pedido, stock y consumo

> Documento de referencia (ingeniería inversa) para este repo. Verificado 2026-11-19.
> Responde: *¿por qué* la app modela el pedido, el stock y el consumo de la forma en que lo hace?
> No es una guía normativa: es la síntesis de cómo operan hospitales grandes y sistemas open source, con fuentes al pie.

## 1) Flujo real y roles

1. **Prescripción**: el médico define fármaco, dosis, vía, frecuencia y duración, y firma. En UCI suele ser urgente y a veces verbal en la emergencia, con registro posterior.
2. **Validación farmacéutica**: el farmacéutico revisa dosis, alergias, interacciones, función renal, duplicidad y equivalencia terapéutica; puede aclarar, rechazar o sustituir. Sin validación no hay despacho, salvo urgencia o stock de sala.
3. **Preparación/picking**: reenvasado en unidosis, mezclas IV en campana, armado del carro por paciente y turno; estupefacientes con doble control.
4. **Entrega**: carro o caja por paciente a la sala, carga del armario automatizado, o entrega de *floor stock* para fármacos críticos; vale/remito con lote y vencimiento.
5. **Administración**: enfermería administra y registra hora, dosis y responsable (hoja de administración o eMAR), incluidas las omisiones.
6. **Devolución**: lo no administrado vuelve con motivo; solo reingresa a stock si conserva trazabilidad de lote y vencimiento.
7. **Reposición**: farmacia repone sala y su stock; depósito reaprovisiona farmacia; compras emite la orden de compra.

**Roles**: médico (prescribe), enfermería (administra, controla botiquín, pide reposición, devuelve), farmacéutico (valida, prepara, controla estupefacientes, concilia), depósito (recibe, ubica, picking, despacha, controla vencimientos), compras (OC y proveedores). **Documentos**: receta/orden, orden de dispensación, vale/remito, hoja de administración, planilla de devolución, acta de baja por vencimiento, kardex de stock, OC y remito de proveedor, libro de estupefacientes. **Estados mínimos**: prescripto → validado → en preparación → despachado → entregado/recibido → administrado, con ramas de aclaración pendiente, rechazado, anulado, devuelto y vencido.

## 2) Modelos de reposición y parámetros

- **Fórmulas base**: punto de pedido = consumo medio diario × *lead time* + stock de seguridad; stock de seguridad ≈ z × σ(demanda) × √(lead time); cantidad de reposición = cobertura objetivo − stock disponible.
- **Par level**: se repone hasta el nivel "par" cuando baja del mínimo. En el caso documentado de armarios automatizados: mínimo de 5 días de consumo medio y máximo de 10 días, ampliado a 12. Simple, pero rígido y propenso a sobrestock.
- **Min-máx**: banda con máximo de 1,5 a 2 veces el mínimo; igual lógica, más tolerancia.
- **Two-bin/kanban**: dos contenedores; vaciar el primero dispara el pedido y el tamaño del bin ≈ demanda durante el *lead time* + seguridad. Da autonomía a enfermería y señal visual; falla por indisciplina y no sirve para ítems caros o de bajo volumen.
- **Unidosis**: farmacia entrega dosis listas para 24 h; menos errores, devolución limpia y trazabilidad, a costo de reenvasado y dependencia de farmacia 24/7.
- **Just-in-time**: entregas frecuentes y stock mínimo; frágil ante quiebres, inadecuado para críticos.
- **ADC (Pyxis/Omnicell)**: acceso por paciente, control por compartimiento, reposición desde el reporte de consumo; cerca del 75 % de los hospitales de EE. UU. los usa como distribución primaria, reducen errores pero generan *workarounds* y diferencias de inventario.
- **Consignación**: el proveedor conserva la propiedad hasta el consumo (implantes, alto costo); exige conciliación y control de vencimientos.

Advertencia: 5/10/12 días proviene de un hospital de 523 camas (EE. UU.); no es norma universal ni trasladable sin datos locales.

## 3) Sistemas open source

| Sistema | Modelo de stock | Reposición | Licencia / stack | Vivo 2024-26 |
|---|---|---|---|---|
| **OpenBoxes** | Producto, lote, ubicación, existencia por lote+ubicación; StockMovement con origen, destino y estado; envíos y OC | Por requisición/envío entre ubicaciones; no verifiqué motor de par-level automático | EPL-1.0; Grails/Java, MySQL | Sí (push 19-11-2026) |
| **OpenLMIS** | Requisición + "tarjetas de stock" con transacciones; productos por programa; envíos con prueba de entrega | Requisición tipo R&R: se inicia, completa, envía y aprueba; cantidad sugerida desde saldo y stock máximo | AGPL-3.0; microservicios Java, PostgreSQL, Docker (reporte con NiFi/Kafka/Druid/Superset) | Sí (push 10-11-2026) |
| **GNU Health** | `health_stock`: movimientos, lotes, envíos, inventario; `health_stock_inpatient`: stock de internación por sala | Parámetros por almacén; el consumo se modela como movimiento | GPL-3.0+; Python/Django + Tryton | Sí (módulos activos; docs 404 hoy) |
| **Bahmni** | Clínico en OpenMRS; inventario y farmacia en Odoo ERP vía Atom Feed | Reglas de reposición de Odoo (min/max) | Java/React; licencia del repo "other" (ecosistema OpenMRS MPL-2.0) | Sí (push 19-11-2026) |
| **HospitalRun** | Ítems con cantidad; arquitectura offline-first (PouchDB/CouchDB) | Manual | MIT; React/TypeScript | **No: archivado en GitHub (ene-2023)** |
| **Care (OHC Network)** | Inventario de recursos y camas; sin lotes verificados en el README | Manual | MIT; Python/Django + React | Sí (push 19-11-2026) |
| **Marley (ex-ERPNext Healthcare)** | Item, Batch, Warehouse, Bin, Stock Ledger Entry, Material Request, Purchase Order, Stock Entry, Stock Reconciliation | `reorder_level` y `reorder_qty` por ítem-almacén; auto-reorder por Material Request | GPL-3.0; Python/Frappe | Sí (push 17-11-2026) |
| **OpenMRS (O3)** | Dispensa como `MedicationDispense` (FHIR) sobre la orden; el descuento de stock no es nativo | No aplica | MPL-2.0; Java + React | Sí (PR abierto para descontar stock) |
| **iHIS** | — | — | — | **No existe como proyecto abierto**: los resultados son productos comerciales e IHiS (agencia de Singapur) |

## 4) Modelo de datos mínimo (UCI, offline-first)

- **Ítem** (medicamento o insumo): id, tipo, nombre genérico, ATC, principio activo, forma, concentración, vía, unidad base canónica (mg, mL, UI, unidad), alto riesgo/estupefaciente, temperatura, código interno.
- **Presentación**: ítem, marca/laboratorio, GTIN, contenido por envase, unidad de consumo, factor de conversión, fraccionable (sí/no), consignación.
- **Lote**: presentación, número, vencimiento, estado (cuarentena/aprobado/rechazado/vencido), proveedor, fecha de recepción.
- **Ubicación**: tipo (depósito, farmacia, sala, botiquín, carro de paro, armario, nevera), jerarquía, cama.
- **Existencia**: por lote y ubicación, en unidad base, más reservado.
- **Movimiento** (ledger inmutable): fecha/hora, tipo (ingreso, egreso, transferencia, consumo, devolución, ajuste, baja por vencimiento, fraccionamiento), ítem, lote, origen/destino, cantidad en unidad base y en presentación, paciente e indicación si es consumo, profesional y firma, motivo, documento origen, saldo resultante.
- **Pedido/requisición**: cabecera (número, fecha/hora, solicitante, sector, paciente/cama, prioridad, estado, autorización, observaciones) y líneas (ítem, presentación, cantidad pedida, unidad, lote/vencimiento, cantidad despachada, faltante).
- **Consumo por indicación**: paciente, indicación (dosis, vía, frecuencia, inicio/fin), administraciones con hora, dosis, responsable y motivo de omisión.
- **Devolución**: pedido, líneas, lote, cantidad, motivo, destino, si reingresa a stock.

**Invariantes**: (1) stock = ingresos − egresos − consumos + devoluciones ± ajustes, sin editar saldos, solo movimientos; (2) FEFO, no FIFO; (3) toda cantidad se guarda en unidad base más la unidad declarada, con conversión presentación↔consumo explícita; (4) stock nunca negativo sin registrar faltante; (5) medicamentos siempre con lote y vencimiento; (6) anulación por contra-movimiento, nunca borrado; (7) offline: ids UUID locales y sello de tiempo/orden causal por dispositivo.

## 5) KPIs y alertas

Fill rate por línea y por unidad (benchmark 95-98 %); quiebre de stock (eventos y días sin stock, campo que OpenLMIS registra explícitamente); días de inventario = stock / consumo medio diario; consumo por paciente-día (DDD/100 camas-día para antimicrobianos); rotación = consumo anual a costo / inventario promedio; vencimientos (% del valor vencido, alertas a 90/60/30 días); exactitud de inventario por conteos cíclicos. Alertas: stock bajo el punto de pedido, lote por vencer, consumo fuera de rango, indicación sin administración registrada, devolución no registrada, diferencia recepción-factura.

## 6) Campos del pedido y trazabilidad

Cabecera: número, tipo (normal/urgente/paro), fecha/hora de creación y requerida, sector y cama, paciente (nombre, HC, peso), profesional solicitante y matrícula, firma, autorización, estado, observaciones. Línea: código interno, ATC/GTIN, descripción genérica y marca, presentación, cantidad pedida, unidad (envase o unidad de consumo), cantidad despachada, lote, vencimiento, faltante, sustituto autorizado. Recepción: quién recibió, fecha/hora, firma, conformidad.

Trazabilidad en Argentina: la **Disposición ANMAT 2891/2026** (14-05-2026, BO 15-05-2026) hizo obligatorio un código bidimensional QR o Data Matrix con tecnología antifraude en el envase secundario, con acceso al prospecto. El **Sistema Nacional de Trazabilidad (SNT)** existe, pero su página no respondió (404): no pude verificar requisitos de serialización. Para estupefacientes y psicotrópicos se usan recetarios oficiales y libros de registro (Ley 19.303 y normativa ANMAT), cuyo texto vigente tampoco verifiqué. GS1 aporta GTIN (AI 01), lote (10), vencimiento (17) y serial (21); la página de GS1 sobre DataMatrix en salud devolvió 403, así que la lista de AIs es conocimiento estándar, no una cita textual. ATC/DDD proviene del índice 2026 del WHOCC.

## 7) Codificación

ATC clasifica el principio activo en 5 niveles y 7 caracteres (p. ej. A02BC01), no la presentación ni la marca: sirve para clase terapéutica y consumo comparado (DDD), no para inventario. SNOMED CT aporta conceptos de fármaco clínico pero exige licencia por país. GS1/GTIN identifica cada nivel de empaque (caja, blíster, ampolla), por lo que un mismo producto tiene varios GTIN. El código interno del vademécum hospitalario debe mapearse a ATC y a GTIN. La conversión presentación↔consumo se resuelve con una tabla por presentación: unidad base canónica, factor de conversión y bandera de fraccionable (una ampolla de 2 mL con 10 mg/mL equivale a 20 mg base). Los insumos descartables no tienen ATC: se codifican por familia y tamaño/calibre, con GTIN o UDI cuando son dispositivos médicos, y su unidad de consumo es la unidad o el par; el control es por punto de pedido, no por dosis.

## Práctica del hospital grande → lección para mi app

| Práctica | Lección |
|---|---|
| Validación farmacéutica previa al despacho | Modelar el pedido con estado "validado" y un campo de observación, aunque hoy no haya farmacéutico en la app |
| Unidosis por paciente y turno | Separar presentación de unidad de consumo y registrar el fraccionamiento |
| Vale/remito con lote y vencimiento | Lote y vencimiento obligatorios en la línea del pedido, no en el ítem |
| Devolución con motivo y reinspección | Entidad de devolución propia, nunca un ajuste negativo suelto |
| Reposición por mínimo/máximo | Guardar punto de pedido y cobertura objetivo por ítem y ubicación |
| FEFO en farmacia y armarios | Ordenar sugerencias por vencimiento, no por antigüedad de ingreso |
| Conteos cíclicos y stock-out | KPI de exactitud y registro explícito de quiebres |
| Registro de administración con hora y responsable | Trazabilidad por indicación, separada del movimiento de stock |

## Fuentes

- OpenBoxes: https://github.com/openboxes/openboxes y https://api.github.com/repos/openboxes/openboxes
- OpenLMIS: https://docs.openlmis.org/en/latest/components/index.html y https://api.github.com/repos/OpenLMIS/openlmis-ref-distro
- GNU Health: https://www.gnuhealth.org/ y https://www.gnuhealth.org/about-us.html
- Bahmni: https://api.github.com/orgs/Bahmni/repos
- HospitalRun: https://api.github.com/repos/HospitalRun/hospitalrun-frontend
- Care: https://raw.githubusercontent.com/ohcnetwork/care/develop/README.md
- Marley/ERPNext Healthcare: https://api.github.com/repositories/399456228
- OpenMRS dispensing: https://raw.githubusercontent.com/openmrs/openmrs-esm-dispensing-app/main/README.md y https://github.com/openmrs/openmrs-esm-dispensing-app/pull/107
- ADC: https://pmc.ncbi.nlm.nih.gov/articles/PMC12240404/
- ANMAT 2891/2026: https://servicios.infoleg.gob.ar/infolegInternet/verNorma.do?id=425844
- ATC/DDD: https://atcddd.fhi.no/atc_ddd_index/
- GS1: https://www.gs1.org/industries/healthcare/2d-barcodes/explorer/2d-barcodes-healthcare (403 al fetchear) y https://www.gs1belu.org/en/identification-medicines
- iHIS: sin proyecto open source verificable (resultados comerciales e IHiS de Singapur)

*Método y límites (del relevamiento): se verificaron repositorios y documentación oficial (API de GitHub: licencia, lenguaje, último push), un artículo de mejora de calidad sobre armarios automatizados y la norma ANMAT 2891/2026. Los PDF de ASHP y de las Declaraciones de Basilea (FIP) no se pudieron descargar (el fetcher rechaza `application/pdf`), así que el flujo de la sección 1 se sintetiza a partir de los modelos de OpenLMIS/OpenMRS y de la práctica descrita en el artículo citado, no de una cita textual de esas guías.*
