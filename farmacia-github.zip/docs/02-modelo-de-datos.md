# Modelo de datos (v3)

> Base para la implementación de stock, pedido y consumo. La v2 manejaba el estado en
> el DOM (pestaña Médico / Enfermería); la v3 lo pasa a un modelo explícito y persistente.

## Principios

1. **El stock es un libro de movimientos inmutable.** Nunca se edita un saldo: se agrega
   un movimiento y el saldo se calcula.
2. **Cantidades en unidad de consumo + factor de presentación.** El catálogo trae
   "FRACCIONADA EN ENVASE DE 100 UNIDADES": se guarda `cantidad_base` y el factor.
3. **FEFO**: para consumir, primero vence primero.
4. **Un identificador por ítem**: el `codigo` del vademécum es la clave compartida con
   las planillas del servicio.
5. **Multi-establecimiento**: configuración y catálogo por hospital; los datos de un
   hospital no se mezclan con los de otro.
6. **Exportar/importar JSON** como mecanismo de sincronización sin servidor.

## Entidades

### Config

```js
{
  establecimiento: { id, nombre, ciudad },
  servicio: { id, nombre },        // UCI A, UCPA, ...
  turnos: [...],                    // mañana, tarde, vespertino, noche
  parametros: { z: 1.65, cv: 0.3, leadTimeDias: 2, coberturaObjetivoDias: 4 }
}
```

### Ítem de catálogo

```js
{
  codigo: "815",                    // clave del vademécum
  nombre: "JERINGA DESCARTABLE 10 ML",
  tipo: "UNIDAD",                   // presentación
  categoria: "Insumos",
  unidadConsumo: "unidad",
  factorPresentacion: 1,            // unidades por envase
  activo: true
}
```

### Movimiento de stock

```js
{
  id: "uuid",
  fecha: "2026-11-19T09:00:00-03:00",
  tipo: "ingreso | consumo | devolucion | transferencia | ajuste | baja",
  codigo: "815",
  cantidad: 10,                     // en unidad de consumo
  lote: "L123",                     // opcional
  vencimiento: "2027-05-31",        // opcional
  origen: "farmacia", destino: "sala",
  paciente: "Cama 3",               // referencia, no identidad completa
  usuario: "Enf. Pérez",
  motivo: "",
  pedidoId: null                    // si viene de una entrega
}
```

### Parámetros de reposición (por ítem)

```js
{
  codigo: "815",
  consumoAnual: 21600,              // del planilla anual
  leadTimeDias: 2,
  z: 1.65, cv: 0.3,                 // desvío
  puntoPedido: 206.8,               // calculado
  stockObjetivo: 277.8,             // calculado
  stockMinimo: 88.5                 // stock de seguridad
}
```

Fórmulas (equivalentes a la planilla del servicio):

```
D = consumoAnual / 365
E = D * 0.6                      // consumo diario real (60 %)
F = 1.65 * (0.3 * D) * sqrt(LT) // desvío estimado
G = D * LT + F                   // stock de seguridad
H = G + (D * PE)                 // punto de pedido (PE = días de cobertura del pedido)
I = H + (E * 2)                  // stock objetivo
sugerido = max(0, I - stockActual)
```

Los números 0.6, 1.65, 0.3, 2, 4 son parámetros de la config: cambiarlos no toca el código.

### Pedido

```js
{
  id: "P-2026-11-19-01",
  fecha, estado: "borrador | enviado | validado | entregado | recibido | anulado",
  servicio, solicitante,
  lineas: [
    { codigo, nombre, tipo, unidad, cantidadPedida, cantidadEntregada, faltante, obs }
  ]
}
```

La salida "copiar y pegar" se genera desde `lineas`:

- **Texto** por renglón: `815 · JERINGA DESCARTABLE 10 ML · 278 UNIDAD`
- **Tabla** con tabs (pegable en Excel)
- **CSV** para exportar

### Indicación y consumo

```js
indicacion: { id, tipo, texto, via, frecuencia, horarios[], medico, estado, farmacia: [ {codigo, cantidad} ] }
consumo:    { indicacionId, codigo, cantidad, turno, fecha, usuario }
```

### Devolución

```js
{ fecha, codigo, cantidad, lote, motivo, reingresaStock: true }
```

## Invariantes

1. `stock(ítem) = Σ ingresos − Σ consumos − Σ transferencias salientes + Σ devoluciones ± ajustes`.
2. Stock nunca negativo sin registrar `faltante`.
3. Movimiento con `lote` incompleto no puede darse de baja por vencimiento.
4. Anulación = contra-movimiento, nunca borrado.
5. Todo movimiento lleva `usuario` y `fecha`.

## Persistencia (localStorage)

| Clave | Contenido |
|---|---|
| `gh:v3:config` | establecimiento, servicio, parámetros |
| `gh:v3:catalogo` | catálogo activo + parámetros de reposición |
| `gh:v3:stock` | movimientos |
| `gh:v3:pedidos` | pedidos |
| `gh:v3:historial` | indicaciones finalizadas |
| `gh:v3:sesion` | paciente/cama/aislamiento y pestaña activa (opcional) |

Formato de exportación:

```json
{
  "app": "gestion-hospitalaria",
  "schema": 3,
  "exportedAt": "2026-11-19T09:00:00-03:00",
  "establecimiento": { "id": "...", "nombre": "..." },
  "config": {},
  "catalogo": [],
  "stock": [],
  "pedidos": [],
  "historial": []
}
```

Al importar: se valida `app` y `schema`, se pide confirmación y se reemplaza solo el
bloque elegido (catálogo, stock o historial).

## Migración v2 → v3

La v2 no persiste; la v3 arranca con estado vacío + catálogo del vademécum, y permite
importar el stock inicial desde un JSON generado con las planillas (`UCIA.xlsx`,
`anual UTIA.xlsx`) mediante un script local que no se publica en el repo por contener
datos internos.

## Lo que NO se versiona

- Datos identificatorios de pacientes.
- Planillas internas (`.xlsx`) y PDFs.
- Tokens o credenciales.
