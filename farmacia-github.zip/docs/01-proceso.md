# Proceso: indicaciones, pedido de farmacia y consumo en sala

> Circuito operativo que la aplicación acompaña y que la v3 va a completar. Basado en el
> flujo de una sala de cuidados críticos y en la referencia de hospitales grandes
> (`docs/03-grandes-hospitales.md`).

## Alcance

Sala de internación (UCI / UTI / UCPA) **sin integración con el sistema informático del
hospital**. La app registra la operación, ordena el pedido y genera una salida que se
**copia y pega** en el sistema oficial, en el correo o en la planilla que use farmacia.

No se guardan datos identificatorios de pacientes en servidores: todo corre en el
navegador del equipo que se use.

## Roles

| Rol | Hace |
|---|---|
| Médico | Prescribe: tipo de indicación, texto, vía, frecuencia, horarios y médico responsable. Autoriza. Finaliza o suspende. |
| Enfermería | Ejecuta las indicaciones por turno, registra atenciones y cargas de insumos/EPP, avisa faltantes y devuelve lo no usado. |
| Farmacia | Recibe el pedido, agrupa por insumo, controla faltantes y entrega. |
| Referente de insumos | Mantiene el stock de la sala, los puntos de pedido y el catálogo. |

## Circuito

```
  Médico ── indicación ──► Enfermería ── ejecución por turno ──► Consumo en sala
                                                                    │
                                                                    ▼
  Farmacia ◄── pedido (copiable) ◄── stock de sala ◄── pedido sugerido
      │                                   ▲
      └── entrega (remito) ───────────────┘
```

1. **Indicación**: el médico carga la orden con los insumos necesarios (del vademécum) y autoriza.
2. **Ejecución**: enfermería ve la indicación en el turno que corresponde y registra la atención.
3. **Consumo**: lo que se usa descuenta stock de la sala (v3).
4. **Pedido**: cuando un insumo baja del **punto de pedido**, entra en el pedido sugerido.
5. **Entrega**: farmacia entrega; el ingreso se registra con lote/vencimiento cuando aplica.
6. **Devolución**: lo no usado vuelve con motivo; reingresa a stock solo si conserva trazabilidad.

## Estados

**Indicación**: pendiente → autorizada → finalizada / suspendida.

**Pedido** (v3): borrador → enviado → validado por farmacia → entregado → recibido.
Ramas: aclaración pendiente, faltante, anulado.

**Movimiento de stock** (v3): ingreso, consumo, devolución, transferencia, ajuste,
baja por vencimiento.

## Documentos que reemplaza o alimenta

| Documento | v2 | v3 |
|---|---|---|
| Hoja de indicaciones | ✅ pestaña Médico | ✅ + persistencia |
| Hoja de enfermería por turno | ✅ pestaña Enfermería | ✅ + consumo descuenta stock |
| Pedido a farmacia | ✅ resumen agrupado | ✅ pedido documentado, copiable/exportable |
| Remito de entrega | — | ✅ ingreso a stock con lote/vencimiento |
| Kardex / planilla de stock | ⚠️ planilla aparte | ✅ dentro de la app |
| Devolución | — | ✅ con motivo |

## Cobertura actual y brechas

| Etapa | v2 | v3 |
|---|---|---|
| Indicación médica | Completa | + persistencia |
| Turnos y atenciones de enfermería | Completa | + consumo por insumo |
| Pedido agrupado | Solo resumen en pantalla | Pedido con estados, sugerido por stock, copiable |
| Stock | ❌ | Kardex + parámetros + alertas |
| Historial de finalizadas | En memoria | Persistido |
| Multi-servicio | Selector de servicio | Establecimiento + catálogo por hospital |

## Criterios de diseño

- **Offline-first**: funciona sin internet una vez cargada (el catálogo es un JSON local).
- **Un archivo de datos**: exportar/importar JSON permite mover la sala entre equipos sin servidor.
- **Sin datos sensibles en la nube**: el estado queda en el navegador.
- **Pedido copiable**: el destino final sigue siendo el sistema del hospital; la app no lo reemplaza.
