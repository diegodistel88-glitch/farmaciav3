#!/usr/bin/env node
/**
 * Test de humo de la app usando jsdom.
 * Uso: node scripts/test-app.js
 * Requiere: npm install --no-save jsdom (solo desarrollo, no se publica).
 */
const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const vademecum = fs.readFileSync(path.join(root, 'data', 'vademecum.json'), 'utf8');

const alerts = [];
let promptQueue = [];
let capturedBlob = null;

const dom = new JSDOM(html, {
  url: 'https://example.test/',
  runScripts: 'dangerously',
  pretendToBeVisual: true,
  beforeParse(window) {
    window.fetch = async () => ({ ok: true, json: async () => JSON.parse(vademecum) });
    window.alert = (m) => alerts.push(String(m));
    window.confirm = () => true;
    window.prompt = () => (promptQueue.length ? promptQueue.shift() : null);
    window.open = () => null;
    window.URL.createObjectURL = (blob) => { capturedBlob = blob; return 'blob:test'; };
    window.URL.revokeObjectURL = () => {};
  },
});

const w = dom.window;
const d = w.document;
const checks = [];
const ok = (name, cond, extra = '') => checks.push({ name, pass: !!cond, extra });
const wait = (ms = 40) => new Promise((r) => setTimeout(r, ms));

(async () => {
  await new Promise((r) => w.addEventListener('load', r, { once: true }));
  await wait(120);

  ok('título actualizado', d.title.includes('Gestión Hospitalaria de Indicaciones'));
  ok('pestaña Insumos presente', !!d.querySelector('.tab-btn[data-tab="tab-insumos"]'));
  ok('vademécum cargado (5174)', d.getElementById('infoContadores').textContent.includes('5174'));

  // Agregar insumo al stock
  w.agregarItemStock({ codigo: '815', nombre: 'JERINGA DESCARTABLE 10 ML', tipo: 'UNIDAD' });
  await wait(10);
  ok('insumo agregado a la tabla', d.querySelectorAll('#tbodyStock tr').length === 1,
    'filas: ' + d.querySelectorAll('#tbodyStock tr').length);

  // Punto de pedido y objetivo
  promptQueue = ['80', '100'];
  d.querySelector('#tbodyStock [data-accion="min"]').click();
  d.querySelector('#tbodyStock [data-accion="obj"]').click();
  await wait(10);
  ok('punto de pedido guardado',
    d.querySelector('#tbodyStock [data-accion="min"]').textContent.trim() === '80',
    'valor: ' + d.querySelector('#tbodyStock [data-accion="min"]').textContent.trim());

  // Ingreso de stock
  promptQueue = ['50', 'compra'];
  d.querySelector('#tbodyStock [data-accion="ingreso"]').click();
  await wait(10);
  ok('stock 50 tras ingreso',
    d.querySelector('#tbodyStock tr td:nth-child(5)').textContent.trim() === '50',
    'celda: ' + d.querySelector('#tbodyStock tr td:nth-child(5)').textContent.trim());

  // Consumo de 5
  promptQueue = ['5', 'uso'];
  d.querySelector('#tbodyStock [data-accion="consumo"]').click();
  await wait(10);
  ok('stock 45 tras consumo',
    d.querySelector('#tbodyStock tr td:nth-child(5)').textContent.trim() === '45');

  // Pedido sugerido: objetivo 100 - stock 45 = 55
  w.renderPedido();
  const sug = d.querySelector('.pedido-cant');
  ok('pedido sugerido con cantidad 55', sug && sug.value === '55',
    'valor: ' + (sug && sug.value));

  // Copiar texto
  d.execCommand = () => true;
  w.copiarTextoPedido();
  const texto = d.getElementById('pedidoTexto').value;
  ok('texto del pedido formateado',
    texto.startsWith('PEDIDO DE FARMACIA') && texto.includes('815 | JERINGA DESCARTABLE 10 ML | 55 | UNIDAD'),
    texto.slice(0, 80));

  // Persistencia
  const guardado = w.localStorage.getItem('gh:v3:stock');
  const data = guardado ? JSON.parse(guardado) : null;
  ok('persistencia en localStorage', data && data.items['815'] && data.items['815'].stock === 45);

  // Respaldo (blob generado, sin navegar)
  const clickOriginal = w.HTMLAnchorElement.prototype.click;
  w.HTMLAnchorElement.prototype.click = () => {};
  w.exportarRespaldo();
  w.HTMLAnchorElement.prototype.click = clickOriginal;
  ok('exportar respaldo genera archivo', !!capturedBlob);

  // Cambio de pestaña
  d.querySelector('.tab-btn[data-tab="tab-insumos"]').click();
  ok('pestaña Insumos se activa', d.getElementById('tab-insumos').classList.contains('active'));

  // Movimientos
  promptQueue = ['50', 'ajuste'];
  d.querySelector('#tbodyStock [data-accion="ajuste"]').click();
  await wait(10);
  ok('ajuste fija stock 50',
    d.querySelector('#tbodyStock tr td:nth-child(5)').textContent.trim() === '50');

  const failed = checks.filter((c) => !c.pass);
  for (const c of checks) {
    console.log(`${c.pass ? 'OK  ' : 'FAIL'}  ${c.name}${c.pass ? '' : '  -> ' + c.extra}`);
  }
  console.log(`\n${checks.length - failed.length}/${checks.length} pruebas OK`);
  if (failed.length) process.exitCode = 1;
})();
