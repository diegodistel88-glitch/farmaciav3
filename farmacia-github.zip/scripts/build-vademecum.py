#!/usr/bin/env python3
"""Genera data/vademecum.json desde data/vademecum.csv.

Formato de entrada (sin encabezado): codigo, tipo/presentacion, nombre.
Formato de salida: [{"codigo": "...", "tipo": "...", "nombre": "..."}, ...]

Uso:  python3 scripts/build-vademecum.py
"""
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CSV = ROOT / "data" / "vademecum.csv"
JSON = ROOT / "data" / "vademecum.json"


def main() -> None:
    with CSV.open(encoding="utf-8-sig", newline="") as fh:
        rows = list(csv.reader(fh))
    items = []
    for row in rows:
        if len(row) < 3:
            continue
        codigo, tipo, nombre = (cell.strip() for cell in row[:3])
        if not nombre:
            continue
        items.append({"codigo": codigo, "tipo": tipo, "nombre": nombre})
    JSON.write_text(
        json.dumps(items, ensure_ascii=False, separators=(",", ":")),
        encoding="utf-8",
    )
    print(f"{len(items)} ítems -> {JSON.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
